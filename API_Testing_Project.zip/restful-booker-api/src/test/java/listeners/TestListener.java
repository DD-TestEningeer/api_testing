package listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.*;

import reports.ExtentManager;

public class TestListener implements ITestListener {
	private static ExtentReports extent = ExtentManager.getInstance();
	private static ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();

	public static ExtentTest getTest() {
		return testThread.get();
	}

	public void onTestStart(ITestResult result) {
		ExtentTest test = extent.createTest(result.getMethod().getMethodName());
		testThread.set(test);
	}

	public void onTestSuccess(ITestResult result) {
		testThread.get().log(Status.PASS, "Test Passed");
	}

	public void onTestFailure(ITestResult result) {
		testThread.get().log(Status.FAIL, "Test Failed: " + result.getThrowable());
	}

	public void onTestSkipped(ITestResult result) {
		testThread.get().log(Status.SKIP, "Test Skipped");
	}

	public void onFinish(ITestContext context) {
		extent.flush();
	}
}
