package retry;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class RetryListener implements ITestListener {

    public void onTestFailure(ITestResult result) {
        System.out.println("Test Failed: " + result.getName());
    }
}
