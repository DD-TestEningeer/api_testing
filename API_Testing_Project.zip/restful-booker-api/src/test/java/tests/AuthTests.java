package tests;

import base.BaseTest;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.ApiUtils;

public class AuthTests extends BaseTest {

    @Test
    public void createTokenTest() {
        JSONObject body = new JSONObject();
        body.put("username", "admin");
        body.put("password", "password123");

        Response response = ApiUtils.post("/auth", body.toString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getString("token").length() > 0);
    }
}
