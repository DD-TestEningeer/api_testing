package tests;

import base.BaseTest;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utils.ApiUtils;
import utils.LoggerHelper;
import org.apache.logging.log4j.Logger;
import com.aventstack.extentreports.Status;
import listeners.TestListener;

@Listeners(TestListener.class)
public class BookingTests extends BaseTest {

    private static final Logger log = LoggerHelper.getLogger(BookingTests.class);

    @Test
    public void createBookingTest() {
        log.info("===== Starting createBookingTest =====");

        JSONObject bookingDates = new JSONObject();
        bookingDates.put("checkin", "2025-08-20");
        bookingDates.put("checkout", "2025-08-25");

        JSONObject body = new JSONObject();
        body.put("firstname", "John");
        body.put("lastname", "Doe");
        body.put("totalprice", 150);
        body.put("depositpaid", true);
        body.put("bookingdates", bookingDates);
        body.put("additionalneeds", "Breakfast");

        log.debug("Request Body: " + body.toString());

        Response response = ApiUtils.post("/booking", body.toString());
        log.info("Response Status Code: " + response.getStatusCode());
        log.debug("Response Body: " + response.getBody().asString());

        TestListener.getTest().log(Status.INFO, "Create Booking Response: " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertNotNull(response.jsonPath().getInt("bookingid"));

        log.info("===== Finished createBookingTest =====");
    }

    @Test
    public void getBookingTest() {
        log.info("===== Starting getBookingTest =====");

        Response response = ApiUtils.get("/booking/1");
        log.info("Response Status Code: " + response.getStatusCode());
        log.debug("Response Body: " + response.getBody().asString());

        TestListener.getTest().log(Status.INFO, "Get Booking Response: " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertNotNull(response.jsonPath().getString("firstname"));

        log.info("===== Finished getBookingTest =====");
    }

    @Test
    public void updateBookingTest() {
        log.info("===== Starting updateBookingTest =====");

        JSONObject bookingDates = new JSONObject();
        bookingDates.put("checkin", "2025-09-01");
        bookingDates.put("checkout", "2025-09-10");

        JSONObject body = new JSONObject();
        body.put("firstname", "Jane");
        body.put("lastname", "Doe");
        body.put("totalprice", 250);
        body.put("depositpaid", false);
        body.put("bookingdates", bookingDates);
        body.put("additionalneeds", "Lunch");

        log.debug("Request Body: " + body.toString());

        Response response = ApiUtils.put("/booking/1", body.toString());
        log.info("Response Status Code: " + response.getStatusCode());
        log.debug("Response Body: " + response.getBody().asString());

        TestListener.getTest().log(Status.INFO, "Update Booking Response: " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);

        log.info("===== Finished updateBookingTest =====");
    }

    @Test
    public void partialUpdateBookingTest() {
        log.info("===== Starting partialUpdateBookingTest =====");

        JSONObject body = new JSONObject();
        body.put("firstname", "UpdatedName");

        log.debug("Request Body: " + body.toString());

        Response response = ApiUtils.patch("/booking/1", body.toString());
        log.info("Response Status Code: " + response.getStatusCode());
        log.debug("Response Body: " + response.getBody().asString());

        TestListener.getTest().log(Status.INFO, "Partial Update Response: " + response.getBody().asPrettyString());

        Assert.assertEquals(response.getStatusCode(), 200);

        log.info("===== Finished partialUpdateBookingTest =====");
    }

    @Test
    public void deleteBookingTest() {
        log.info("===== Starting deleteBookingTest =====");

        Response response = ApiUtils.delete("/booking/1");
        log.info("Response Status Code: " + response.getStatusCode());
        log.debug("Response Body: " + response.getBody().asString());

        TestListener.getTest().log(Status.INFO, "Delete Booking Response: " + response.getBody().asPrettyString());

        Assert.assertTrue(response.getStatusCode() == 201 || response.getStatusCode() == 200);

        log.info("===== Finished deleteBookingTest =====");
    }
}
