package endpoints;

public class AuthEndpoints {

}
