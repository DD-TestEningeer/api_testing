package endpoints;

public class BookingEndpoints {

}
