package models;

public class BookingRequest {

}
