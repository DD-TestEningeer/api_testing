package models;

public class AuthRequest {

}
